# Kaleidoscope 1 Puppet Module for Boxen

## Usage

```puppet
include kaleidoscope
```

## Required Puppet Modules

* `boxen`

## Development

Write some code.

Run `script/cibuild` to test it.
