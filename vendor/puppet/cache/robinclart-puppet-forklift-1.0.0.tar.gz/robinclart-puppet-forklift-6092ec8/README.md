# ForkLift Puppet Module for Boxen

[![Build Status](https://travis-ci.org/robinclart/puppet-forklift.png?branch=master)](https://travis-ci.org/robinclart/puppet-forklift)

## Usage

```puppet
include forklift
```

## Required Puppet Modules

* `boxen`

## Development

Write some code.

Run `script/cibuild` to test it.
